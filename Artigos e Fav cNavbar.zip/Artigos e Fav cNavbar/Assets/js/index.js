document.addEventListener('DOMContentLoaded', () => {
  const fileGrid = document.getElementById("file-grid");
  let favoritos = JSON.parse(localStorage.getItem('favoritos')) || [];

  function renderFavoritos() {
    fileGrid.innerHTML = '';

    if (favoritos.length === 0) {
      const noFavoritosMessage = document.createElement("div");
      noFavoritosMessage.classList.add("no-favorites-message");
      noFavoritosMessage.textContent = "Você não possui nenhum item favoritado";
      fileGrid.appendChild(noFavoritosMessage);
    } else {
      favoritos.forEach((file, index) => {
        const fileItem = document.createElement("div");
        fileItem.classList.add("file");
        fileItem.innerHTML = `
                <div class="linha">
                    <div><a href="${file.url}" target="_blank">${file.nome}</a></div>
                    <div><button class="btn favorite-btn favorited" data-index="${index}">Remover Favorito</button></div>
                </div>`;
        fileGrid.appendChild(fileItem);
      });

      const buttons = document.querySelectorAll('.favorite-btn');
      buttons.forEach(button => {
        button.addEventListener('click', () => {
          const index = button.getAttribute('data-index');
          removeFavorito(index);
        });
      });
    }
  }

  function removeFavorito(Artigos) {
    favoritos.splice(Artigos, 1);
    localStorage.setItem('favoritos', JSON.stringify(favoritos));
    renderFavoritos();
  }

  renderFavoritos();
});