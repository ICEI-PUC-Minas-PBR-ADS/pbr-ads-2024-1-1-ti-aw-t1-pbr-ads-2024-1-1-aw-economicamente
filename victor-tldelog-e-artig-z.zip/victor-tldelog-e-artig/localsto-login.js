// Array para armazenar os registros
let registros = [];

// Função para adicionar um novo registro
function adicionarRegistro() {
    const novoRegistro = {
        titulo: "Adicione ",
        conteudo: ""
    };
    registros.push(novoRegistro);
    atualizarTela();
}


function excluirRegistro() {
    registros.pop();
    atualizarTela();
}

// Função para atualizar a tela com os registros
function atualizarTela() {
    const containerRegistros = document.getElementById("containerRegistros");
    containerRegistros.innerHTML = ""; // Limpa o conteúdo atual

    // Adiciona os registros à tela
    registros.forEach(registro => {
        const divRegistro = document.createElement("div");
        divRegistro.classList.add("card", "mb-3", "col-md-6"); 
        divRegistro.innerHTML = `
            <div class="card-body">
                <h5 class="card-title">${registro.titulo}</h5>
                <p>${registro.conteudo}</p>
            </div>
        `;
        containerRegistros.appendChild(divRegistro);
    });
}



document.getElementById("adicionarRegistro").addEventListener("click", adicionarRegistro);
document.getElementById("excluirRegistro").addEventListener("click", excluirRegistro);
