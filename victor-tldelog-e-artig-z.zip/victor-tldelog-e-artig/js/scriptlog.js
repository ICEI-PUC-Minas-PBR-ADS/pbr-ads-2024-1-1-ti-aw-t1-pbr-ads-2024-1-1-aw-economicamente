document.addEventListener('DOMContentLoaded', function() {
    // Captura o formulário
    const loginForm = document.getElementById('loginForm');
    
    // Adiciona um evento ao formulário para quando ele for submetido
    loginForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Previne o comportamento padrão do formulário

        // Captura os valores dos campos
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        // Salva os valores no Local Storage
        localStorage.setItem('username', username);
        localStorage.setItem('password', password);

        // Mostra uma mensagem de sucesso
        const loginMessage = document.getElementById('loginMessage');
        loginMessage.textContent = 'Usuário e senha salvos com sucesso!';
        loginMessage.classList.add('alert', 'alert-success');

        // Limpa os campos do formulário
        loginForm.reset();
    });

    // Recupera os valores ao carregar a página
    const savedUsername = localStorage.getItem('username');
    const savedPassword = localStorage.getItem('password');
    if (savedUsername) {
        document.getElementById('username').value = savedUsername;
    }
    if (savedPassword) {
        document.getElementById('password').value = savedPassword;
    }
});
