$(document).ready(function () {
  const apiUrl = 'http://localhost:3000/login';

  $('#loginForm').submit(function (event) {
    event.preventDefault();
   
    const username = $('#username').val();
    const password = $('#password').val();

    const userData = {
      username: username,
      password: password
    };

    
    $.ajax({
      type: 'POST',
      url: apiUrl,
      contentType: 'application/json',
      data: JSON.stringify(userData),
      success: function (response) {
        
        if (response.success) {
          $('#loginMessage').text('Login bem-sucedido!').css('color', 'green');
        } else {
          $('#loginMessage').text('Usuário ou senha incorretos.').css('color', 'red');
        }
      },
      error: function (xhr, status, error) {
        
        console.error(error);
        $('#loginMessage').text('Erro ao fazer login.').css('color', 'red');
      }
    });
  });
});
